package com.example.alarm

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.database.DataSetObserver
import android.graphics.drawable.AnimationDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.widget.TextViewCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textview.MaterialTextView
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity(),AdapterView.OnItemSelectedListener {
   private val calendar=Calendar.getInstance()

    private lateinit var notificationbutton: AnimationDrawable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




        val textView: TextView = findViewById(R.id.textView1)
        var spinndervalue: String
        val spinner: Spinner = findViewById(R.id.notificationSpinner)



        spinner.onItemSelectedListener=this
        spinner.adapter = ArrayAdapter.createFromResource(
            this,
            R.array.notificationNames,
            android.R.layout.simple_dropdown_item_1line
        ).also { adapter -> adapter.setDropDownViewResource(android.R.layout.simple_spinner_item) }


        val notification = findViewById<ImageView>(R.id.imageView).apply {
            setBackgroundResource(R.drawable.notificationchanges)
            notificationbutton = background as AnimationDrawable
        }

        notification.setOnClickListener(){
           notificationbutton.start()

        }



    }
    override fun onNothingSelected(p0: AdapterView<*>?) {

        Toast.makeText(this,"Select",Toast.LENGTH_SHORT).show()
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

        val timePicker=TimePickerDialog(this, TimePickerDialog.OnTimeSetListener{view,hourofday,minute->},
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            false)
        timePicker.show()

    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.notificationlist, menu)
        return true
    }
}
